package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author
 * @version 2022-02-25
 */
public class CAS extends Professor {
    String term;

    public CAS(String lastName, String firstName, String deparment, String term) {
	super(lastName, firstName, deparment);

	this.term = term;
    }

    /**
     * Getter for term.
     *
     * @return this.course
     */
    public String getTerm() {
	return this.term;

    }

    /**
     * Creates formatted string version of Person.
     */
    @Override
    public String toString() {

	return (super.toString() + "\nTerm: " + this.term);
    }

}
