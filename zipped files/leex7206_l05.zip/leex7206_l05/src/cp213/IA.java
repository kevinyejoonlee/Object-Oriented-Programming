package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author David Brown
 * @version 2022-02-25
 */
public class IA extends Student {
    String course;

    public IA(String lastName, String firstName, String id, String course) {
	super(lastName, firstName, id);
	this.course = course;
    }

    /**
     * Getter for course.
     *
     * @return this.course
     */
    public String getCourse() {
	return this.course;

    }

    /**
     * Creates formatted string version of Person.
     */
    @Override
    public String toString() {
	return (super.toString() + "\nCourse: " + this.course);
    }

}