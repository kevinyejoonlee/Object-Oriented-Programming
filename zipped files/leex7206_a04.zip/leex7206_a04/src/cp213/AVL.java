package cp213;

/**
 * Implements an AVL (Adelson-Velsky Landis) tree. Extends BST.
 *
 * @author Kevin Lee, 210872060
 * @author David Brown
 * @version 2022-05-12
 */
public class AVL<T extends Comparable<T>> extends BST<T> {

    /**
     * Returns the balance item of node. If greater than 1, then left heavy, if less
     * than -1, then right heavy. If in the range -1 to 1 inclusive, the node is
     * balanced. Used to determine whether to rotate a node upon insertion.
     *
     * @param node The TreeNode to analyze for balance.
     * @return A balance number.
     */
    private int balance(final TreeNode<T> node) {
	if (node == null)
	    return 0;

	int leftHeight = 0;
	int rightHeight = 0;

	if (node.getLeft() != null) {
	    leftHeight = node.getLeft().getHeight();
	}
	if (node.getRight() != null) {
	    rightHeight = node.getRight().getHeight();
	}

	return (leftHeight - rightHeight);
    }

    /**
     * Performs a left rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateLeft(final TreeNode<T> node) {
	TreeNode<T> r = node.getRight();
	node.setRight(r.getLeft());
	r.setLeft(node);

	node.updateHeight();
	r.updateHeight();

	return r;
    }

    /**
     * Performs a right rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateRight(final TreeNode<T> node) {
	TreeNode<T> l = node.getLeft();
	node.setLeft(l.getRight());
	l.setRight(node);

	node.updateHeight();
	l.updateHeight();

	return l;
    }

    /**
     * Auxiliary method for insert. Inserts data into this AVL.
     *
     * @param node The current node (TreeNode).
     * @param cs   Data to be inserted into the node.
     * @return The inserted node.
     */
    @Override
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedStore<T> cs) {
	if (node == null) {
	    node = new TreeNode<T>(cs);
	    node.getCs().incrementCount();
	    this.size++;
	} else {
	    this.comparisons++;
	    if (node.getCs().compareTo(cs) > 0)
		node.setLeft(insertAux(node.getLeft(), cs));
	    else if (node.getCs().compareTo(cs) < 0)
		node.setRight(insertAux(node.getRight(), cs));
	    else
		node.getCs().incrementCount();
	}

	node.updateHeight();
	int balanceFactor = balance(node);

	if (balanceFactor > 1) {

	    int leftChildBalanceFactor = balance(node.getLeft());
	    if (leftChildBalanceFactor < 0) {

		node.setLeft(rotateLeft(node.getLeft()));
		node = rotateRight(node);
	    } else {

		node = rotateRight(node);
	    }
	} else if (balanceFactor < -1) {

	    int rightChildBalanceFactor = balance(node.getRight());
	    if (rightChildBalanceFactor > 0) {

		node.setRight(rotateRight(node.getRight()));
		node = rotateLeft(node);
	    } else {

		node = rotateLeft(node);
	    }
	}

	return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree. An AVL must meet the BST validation conditions, and additionally be
     * balanced in all its subtrees - i.e. the difference in height between any two
     * children must be no greater than 1.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    @Override
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {
	if (node == null)
	    return true;

	this.comparisons++;
	if (minNode != null && node.getCs().compareTo(minNode.getCs()) < 0
		|| maxNode != null && node.getCs().compareTo(maxNode.getCs()) > 0)
	    return false;

	int balanceFactor = balance(node);
	if (balanceFactor < -1 || balanceFactor > 1)
	    return false;

	if (this.isValidAux(node.getLeft(), minNode, node))
	    if (this.isValidAux(node.getRight(), node, maxNode))
		return true;

	return false;
    }

    /**
     * Determines whether two AVLs are identical.
     *
     * @param target The AVL to compare this AVL against.
     * @return true if this AVL and target contain nodes that match in position,
     *         item, count, and height, false otherwise.
     */
    public boolean equals(final AVL<T> target) {
	return super.equals(target);
    }

}
