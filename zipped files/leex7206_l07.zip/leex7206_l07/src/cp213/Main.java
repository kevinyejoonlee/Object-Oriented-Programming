package cp213;

import javax.swing.JFrame;

/**
 * Testing simple example of GUI widgets and inner classes.
 *
 * @author David Brown
 * @version 2022-07-09
 */
public class Main {

    /**
     * Test code.
     *
     * @param args Unused.
     */
    public static void main(String[] args) {
	// Create the display panel.
	final InnerClassPanel view = new InnerClassPanel();
	// Create the program frame and add the panel to it.
	final JFrame f = new JFrame("Inner Class Examples");
	f.setContentPane(view);
	f.setSize(300, 500);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setVisible(true);

    }
}

////Constants
//private static final int START = 0;
//private static final int END = 100;
//private static final int INC = 5;
//private static final String[] MONTH_STRINGS = new DateFormatSymbols().getMonths();
//private static final SpinnerListModel MONTH_MODEL = new SpinnerListModel(MONTH_STRINGS);
//
//// Attributes
//private String buttonPush = "";
//private String radioButtonSet = "";
//private int sliderSet = START;
//private String spinnerSet = "";
//private String textEntry = "";
//
//// GUI elements
//private final JButton button = new JButton("Push Me");
//private final ArrayList<String> checkBoxesSelected = new ArrayList<>();
//private final JCheckBox ketchup = new JCheckBox("Ketchup");
//private final JLabel label = new JLabel();
//private final JCheckBox mustard = new JCheckBox("Mustard");
//private final JCheckBox onions = new JCheckBox("Onions");
//private final JSlider slider = new JSlider(JSlider.HORIZONTAL, START, END, INC);
//private final JSpinner spinner = new JSpinner(MONTH_MODEL);
//private final ButtonGroup starGroup = new ButtonGroup();
//private final JRadioButton starTrek = new JRadioButton("Star Trek");
//private final JRadioButton starWars = new JRadioButton("Star Wars");
//private final JTextField textField = new JTextField();
